
  # Onboarding WeSpeak Payment Links

  This is a code bundle for Onboarding WeSpeak Payment Links. The original project is available at https://www.figma.com/design/wE8oO1EQguoazbNPXNJjB7/Onboarding-WeSpeak-Payment-Links.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  